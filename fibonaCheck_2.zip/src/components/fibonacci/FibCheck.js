import React from 'react'

const fib = ({ fib }) => {
    if (fib.statusBool) {
        return (
            <div className="flex text-2xl">
                {fib.is ? (<strong className="font-bold pr-2">{fib.is}.</strong>) : null}
                <span>{fib.status}</span>
            </div>
        )
    }
    return <div className="text-2xl">Fibonacci Değil</div>
}

export default fib;
