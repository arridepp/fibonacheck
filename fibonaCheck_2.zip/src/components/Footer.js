import React from 'react'

export default function Footer() {
    return (
        <footer className="flex justify-center">
            <strong className="text-white text-2xl">© Copyright ARRi Depp</strong>
        </footer>
    );
}